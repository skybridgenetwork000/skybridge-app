package com.skybridg.linexware.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;

/**
 * Drop-in replacement tag for a vertical LinearLayout that adds Lottie-powered
 * swipe-to-refresh behavior, with an elastic "rubber band" overscroll past the
 * normal pull limit and a soft bounce-back on release.
 *
 * Usage in XML: change the tag name of your existing LinearLayout to the
 * fully-qualified name of this class. Every attribute you already have
 * (orientation, gravity, children, etc.) is left completely untouched.
 *
 * In code:
 *   LottieSwipeRefreshLayout layout = findViewById(R.id.linear1);
 *   layout.setOnRefreshListener(() -> {
 *       // your refresh work
 *       layout.setRefreshing(false); // call when done
 *   });
 */
public class LottieSwipeRefreshLayout extends LinearLayout {

    public interface OnRefreshListener {
        void onRefresh();
    }

    private static final float DRAG_RATE = 0.5f;      // dampens finger movement before the limit
    private static final float RUBBER_BAND_C = 0.55f; // resistance constant for the overscroll
    private static final int SNAP_DURATION = 320;     // ms, bounce-to-limit / collapse-to-zero
    private static final Interpolator BOUNCE_INTERPOLATOR = new OvershootInterpolator(1.3f);

    private LottieAnimationView lottieView;
    private int maxHeaderHeightPx;   // normal pull limit — also the height refresh settles at
    private int overstretchExtraPx;  // extra elastic room allowed beyond the limit
    private int touchSlop;

    private float initialDownY;
    private boolean isDragging;
    private boolean refreshing;
    private ValueAnimator headerAnimator;
    private OnRefreshListener listener;

    public LottieSwipeRefreshLayout(Context context) {
        super(context);
        init(context);
    }

    public LottieSwipeRefreshLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context) {
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        maxHeaderHeightPx = dpToPx(72);   // normal swipe-down limit
        overstretchExtraPx = dpToPx(40);  // extra rubber-band room past that limit

        lottieView = new LottieAnimationView(context);
        lottieView.setAnimation("loading.json"); // expects assets/loading_lottie.json
        lottieView.setRepeatCount(LottieDrawable.INFINITE);
        lottieView.setProgress(0f);

        LayoutParams headerParams = new LayoutParams(LayoutParams.MATCH_PARENT, 0);
        headerParams.gravity = Gravity.CENTER_HORIZONTAL;

        // Always inserted at index 0. Your original children keep whatever
        // index/order/gravity they already had — untouched.
        addView(lottieView, 0, headerParams);
    }

    /** Normal pull distance (dp) before the elastic rubber-band kicks in. */
    public void setPullDistanceDp(int dp) {
        maxHeaderHeightPx = dpToPx(dp);
    }

    /** Extra elastic room (dp) allowed past the pull limit before it maxes out. */
    public void setOverstretchDistanceDp(int dp) {
        overstretchExtraPx = dpToPx(dp);
    }

    public void setOnRefreshListener(OnRefreshListener listener) {
        this.listener = listener;
    }

    public boolean isRefreshing() {
        return refreshing;
    }

    /**
     * Call with true to force-start the refresh state, and with false when your
     * refresh work is done to collapse the view back down.
     */
    public void setRefreshing(boolean refreshing) {
        this.refreshing = refreshing;
        if (refreshing) {
            // Bounces from wherever it currently sits (including an overstretched
            // position) down to the normal limit, then starts the loop animation.
            animateHeaderHeight(getHeaderHeight(), maxHeaderHeightPx, BOUNCE_INTERPOLATOR, () -> {
                lottieView.setProgress(0f);
                lottieView.playAnimation();
            });
        } else {
            lottieView.cancelAnimation();
            // Collapses away with the same soft bounce feel, then resets.
            animateHeaderHeight(getHeaderHeight(), 0, BOUNCE_INTERPOLATOR, () -> lottieView.setProgress(0f));
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                initialDownY = ev.getY();
                isDragging = false;
                break;
            case MotionEvent.ACTION_MOVE:
                float dy = ev.getY() - initialDownY;
                if (dy > touchSlop && !refreshing && !canChildScrollUp()) {
                    isDragging = true;
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isDragging = false;
                break;
            default:
                break;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!isDragging) {
            return super.onTouchEvent(ev);
        }

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_MOVE: {
                float dy = ev.getY() - initialDownY;
                float dragged = Math.max(0f, dy * DRAG_RATE);

                int height;
                if (dragged <= maxHeaderHeightPx) {
                    height = (int) dragged;
                } else {
                    // Past the normal limit: diminishing-return rubber band, so it
                    // keeps stretching but resists more the further you pull.
                    float overPull = dragged - maxHeaderHeightPx;
                    float extra = rubberBand(overPull, overstretchExtraPx);
                    height = (int) (maxHeaderHeightPx + extra);
                }
                setHeaderHeight(height);

                // Lottie's own progress caps at 1 once we hit the normal limit —
                // the extra elastic stretch beyond that doesn't scrub the animation further.
                float progress = maxHeaderHeightPx == 0
                        ? 0f
                        : Math.min(height, maxHeaderHeightPx) / (float) maxHeaderHeightPx;
                lottieView.setProgress(progress);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                isDragging = false;
                int currentHeight = getHeaderHeight();
                if (currentHeight >= maxHeaderHeightPx) {
                    // Reached (or stretched past) the limit — bounce back down to
                    // the limit and start loading.
                    setRefreshing(true);
                    if (listener != null) {
                        listener.onRefresh();
                    }
                } else if (currentHeight > 0) {
                    // Didn't pull far enough — spring back closed, no refresh.
                    animateHeaderHeight(currentHeight, 0, BOUNCE_INTERPOLATOR, null);
                }
                return true;
            }
            default:
                break;
        }
        return super.onTouchEvent(ev);
    }

    /**
     * iOS-style rubber-band resistance curve: as overPull grows, the returned
     * extra height approaches maxOver asymptotically but never exceeds it.
     */
    private float rubberBand(float overPull, float maxOver) {
        if (maxOver <= 0) {
            return 0f;
        }
        return (float) ((1f - (1f / ((overPull * RUBBER_BAND_C / maxOver) + 1f))) * maxOver);
    }

    /** Returns true if any content child below the header can still scroll up. */
    private boolean canChildScrollUp() {
        for (int i = 1; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.canScrollVertically(-1)) {
                return true;
            }
        }
        return false;
    }

    private int getHeaderHeight() {
        return lottieView.getLayoutParams().height;
    }

    private void setHeaderHeight(int px) {
        LayoutParams params = (LayoutParams) lottieView.getLayoutParams();
        params.height = Math.max(0, px);
        lottieView.setLayoutParams(params);
    }

    private void animateHeaderHeight(int from, int to, @Nullable Interpolator interpolator, @Nullable Runnable onEnd) {
        if (headerAnimator != null) {
            headerAnimator.cancel();
        }
        headerAnimator = ValueAnimator.ofInt(from, to);
        headerAnimator.setDuration(SNAP_DURATION);
        if (interpolator != null) {
            headerAnimator.setInterpolator(interpolator);
        }
        headerAnimator.addUpdateListener(anim -> setHeaderHeight((int) anim.getAnimatedValue()));
        if (onEnd != null) {
            headerAnimator.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    onEnd.run();
                }
            });
        }
        headerAnimator.start();
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
