package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import android.net.Uri;
import android.graphics.Color;

public class MenuActivity extends AppCompatActivity {
	
	private HashMap<String, Object> data = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private LinearLayout linear3;
	private CircleImageView circleimageview1;
	private TextView textview1;
	private TextView textview28;
	private LinearLayout linear10;
	private TextView textview2;
	private LinearLayout linear4;
	private TextView textview24;
	private LinearLayout linear38;
	private TextView textview19;
	private LinearLayout linear30;
	private LinearLayout linear25;
	private LinearLayout linear42;
	private LinearLayout linear27;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear18;
	private TextView textview9;
	private TextView textview10;
	private ImageView imageview5;
	private LinearLayout linear19;
	private TextView textview14;
	private ImageView imageview6;
	private TextView textview11;
	private TextView textview12;
	private LinearLayout linear5;
	private LinearLayout linear14;
	private LinearLayout linear21;
	private LinearLayout linear23;
	private ImageView imageview2;
	private TextView textview3;
	private ImageView imageview7;
	private TextView textview13;
	private ImageView imageview9;
	private TextView textview16;
	private ImageView imageview11;
	private TextView textview17;
	private LinearLayout linear39;
	private LinearLayout linear41;
	private ImageView imageview23;
	private TextView textview25;
	private ImageView imageview25;
	private TextView textview26;
	private ImageView imageview19;
	private TextView textview22;
	private ImageView imageview13;
	private TextView textview18;
	private ImageView imageview27;
	private TextView textview27;
	
	private SharedPreferences d_;
	private Intent i_ = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.menu);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview1 = findViewById(R.id.textview1);
		textview28 = findViewById(R.id.textview28);
		linear10 = findViewById(R.id.linear10);
		textview2 = findViewById(R.id.textview2);
		linear4 = findViewById(R.id.linear4);
		textview24 = findViewById(R.id.textview24);
		linear38 = findViewById(R.id.linear38);
		textview19 = findViewById(R.id.textview19);
		linear30 = findViewById(R.id.linear30);
		linear25 = findViewById(R.id.linear25);
		linear42 = findViewById(R.id.linear42);
		linear27 = findViewById(R.id.linear27);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear18 = findViewById(R.id.linear18);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
		imageview5 = findViewById(R.id.imageview5);
		linear19 = findViewById(R.id.linear19);
		textview14 = findViewById(R.id.textview14);
		imageview6 = findViewById(R.id.imageview6);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		linear5 = findViewById(R.id.linear5);
		linear14 = findViewById(R.id.linear14);
		linear21 = findViewById(R.id.linear21);
		linear23 = findViewById(R.id.linear23);
		imageview2 = findViewById(R.id.imageview2);
		textview3 = findViewById(R.id.textview3);
		imageview7 = findViewById(R.id.imageview7);
		textview13 = findViewById(R.id.textview13);
		imageview9 = findViewById(R.id.imageview9);
		textview16 = findViewById(R.id.textview16);
		imageview11 = findViewById(R.id.imageview11);
		textview17 = findViewById(R.id.textview17);
		linear39 = findViewById(R.id.linear39);
		linear41 = findViewById(R.id.linear41);
		imageview23 = findViewById(R.id.imageview23);
		textview25 = findViewById(R.id.textview25);
		imageview25 = findViewById(R.id.imageview25);
		textview26 = findViewById(R.id.textview26);
		imageview19 = findViewById(R.id.imageview19);
		textview22 = findViewById(R.id.textview22);
		imageview13 = findViewById(R.id.imageview13);
		textview18 = findViewById(R.id.textview18);
		imageview27 = findViewById(R.id.imageview27);
		textview27 = findViewById(R.id.textview27);
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		linear25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_chromeTab("https://skybridge.linexware.net.ng/privacy%26policy/");
			}
		});
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				CustomToast.showInfo(MenuActivity.this, "KYC Verification", "The KYC Verification is unavailable at the moment!!");
				
			}
		});
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i_.setClass(getApplicationContext(), ProfileActivity.class);
				i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i_.setClass(getApplicationContext(), ThemeActivity.class);
				i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear39.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_chromeTab("https://skybridge.linexware.net.ng/whitepaper/");
			}
		});
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_ui_();
		_font_();
		_theme_();
		_check_data_();
		vscroll1.setVerticalScrollBarEnabled(false); vscroll1.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Override
	public void onBackPressed() {
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	public void _ui_() {
		
	}
	
	
	public void _font_() {
		textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview28.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		textview14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview16.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview17.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview25.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview26.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview22.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview18.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview24.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview19.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview19.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
			} else {
				_light_();
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
		}
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundColor(0xFF000000);
		imageview1.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(18)), 0xFF212121));
		imageview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		SvgView.GetAsster(getApplicationContext() , imageview5 , "profile/shield-security.svg");
		SvgView.GetAsster(getApplicationContext() , imageview6 , "profile/gift.svg");
		textview14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF212121));
		imageview7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview25.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview19.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview27.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		DashUtils.setDashedStroke(linear13, Color.parseColor("#212121"), 3, 15f, 6f, SketchwareUtil.getDip(getApplicationContext(), (int)(20)));
		DashUtils.setDashedStroke(linear12, Color.parseColor("#212121"), 3, 15f, 6f, SketchwareUtil.getDip(getApplicationContext(), (int)(20)));
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(0xFF212121);
		gd.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear5.setBackground(gd);
		android.graphics.drawable.GradientDrawable bb = new android.graphics.drawable.GradientDrawable();
		bb.setColor(0xFF212121);
		bb.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear23.setBackground(bb);
		android.graphics.drawable.GradientDrawable gg = new android.graphics.drawable.GradientDrawable();
		gg.setColor(0xFF212121);
		gg.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear39.setBackground(gg);
		android.graphics.drawable.GradientDrawable hh = new android.graphics.drawable.GradientDrawable();
		hh.setColor(0xFF212121);
		hh.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear41.setBackground(hh);
		android.graphics.drawable.GradientDrawable gk = new android.graphics.drawable.GradientDrawable();
		gk.setColor(0xFF212121);
		gk.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear30.setBackground(gk);
		android.graphics.drawable.GradientDrawable hk = new android.graphics.drawable.GradientDrawable();
		hk.setColor(0xFF212121);
		hk.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear25.setBackground(hk);
		android.graphics.drawable.GradientDrawable ho = new android.graphics.drawable.GradientDrawable();
		ho.setColor(0xFF212121);
		ho.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear42.setBackground(ho);
		android.graphics.drawable.GradientDrawable ht = new android.graphics.drawable.GradientDrawable();
		ht.setColor(0xFF212121);
		ht.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear14.setBackground(ht);
		android.graphics.drawable.GradientDrawable hm = new android.graphics.drawable.GradientDrawable();
		hm.setColor(0xFF212121);
		hm.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear21.setBackground(hm);
		textview1.setTextColor(0xFFFFFFFF);
		textview28.setTextColor(0xFF616161);
		textview2.setTextColor(0xFF9E9E9E);
		textview24.setTextColor(0xFF9E9E9E);
		textview19.setTextColor(0xFF9E9E9E);
		textview9.setTextColor(0xFFFFFFFF);
		textview10.setTextColor(0xFF757575);
		textview14.setTextColor(0xFFFFFFFF);
		textview11.setTextColor(0xFFFFFFFF);
		textview12.setTextColor(0xFF757575);
		textview3.setTextColor(0xFFFFFFFF);
		textview13.setTextColor(0xFFFFFFFF);
		textview16.setTextColor(0xFFFFFFFF);
		textview17.setTextColor(0xFFFFFFFF);
		textview25.setTextColor(0xFFFFFFFF);
		textview26.setTextColor(0xFFFFFFFF);
		textview22.setTextColor(0xFFFFFFFF);
		textview18.setTextColor(0xFFFFFFFF);
		imageview2.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview7.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview9.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview11.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview23.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview25.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview19.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview13.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundColor(0xFFFFFFFF);
		imageview1.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(18)), 0xFFEEEEEE));
		imageview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		SvgView.GetAsster(getApplicationContext() , imageview5 , "profile/shield-security.svg");
		SvgView.GetAsster(getApplicationContext() , imageview6 , "profile/gift.svg");
		textview14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFEEEEEE));
		imageview7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview25.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview19.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview27.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		DashUtils.setDashedStroke(linear13, Color.parseColor("#e0e0e0"), 3, 15f, 6f, SketchwareUtil.getDip(getApplicationContext(), (int)(20)));
		DashUtils.setDashedStroke(linear12, Color.parseColor("#e0e0e0"), 3, 15f, 6f, SketchwareUtil.getDip(getApplicationContext(), (int)(20)));
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(0xFFEEEEEE);
		gd.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear5.setBackground(gd);
		android.graphics.drawable.GradientDrawable bb = new android.graphics.drawable.GradientDrawable();
		bb.setColor(0xFFEEEEEE);
		bb.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear23.setBackground(bb);
		android.graphics.drawable.GradientDrawable gg = new android.graphics.drawable.GradientDrawable();
		gg.setColor(0xFFEEEEEE);
		gg.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear39.setBackground(gg);
		android.graphics.drawable.GradientDrawable hh = new android.graphics.drawable.GradientDrawable();
		hh.setColor(0xFFEEEEEE);
		hh.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear41.setBackground(hh);
		android.graphics.drawable.GradientDrawable gk = new android.graphics.drawable.GradientDrawable();
		gk.setColor(0xFFEEEEEE);
		gk.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear30.setBackground(gk);
		android.graphics.drawable.GradientDrawable hk = new android.graphics.drawable.GradientDrawable();
		hk.setColor(0xFFEEEEEE);
		hk.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear25.setBackground(hk);
		android.graphics.drawable.GradientDrawable ho = new android.graphics.drawable.GradientDrawable();
		ho.setColor(0xFFEEEEEE);
		ho.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20)),SketchwareUtil.getDip(getApplicationContext(), (int)(20))});
		linear42.setBackground(ho);
		android.graphics.drawable.GradientDrawable ht = new android.graphics.drawable.GradientDrawable();
		ht.setColor(0xFFEEEEEE);
		ht.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear14.setBackground(ht);
		android.graphics.drawable.GradientDrawable hm = new android.graphics.drawable.GradientDrawable();
		hm.setColor(0xFFEEEEEE);
		hm.setCornerRadii(new float[] {SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10)),SketchwareUtil.getDip(getApplicationContext(), (int)(10))});
		linear21.setBackground(hm);
		textview1.setTextColor(0xFF000000);
		textview28.setTextColor(0xFF9E9E9E);
		textview2.setTextColor(0xFF9E9E9E);
		textview24.setTextColor(0xFF9E9E9E);
		textview19.setTextColor(0xFF9E9E9E);
		textview9.setTextColor(0xFF000000);
		textview10.setTextColor(0xFF9E9E9E);
		textview14.setTextColor(0xFF9E9E9E);
		textview11.setTextColor(0xFF000000);
		textview12.setTextColor(0xFF9E9E9E);
		textview3.setTextColor(0xFF000000);
		textview13.setTextColor(0xFF000000);
		textview16.setTextColor(0xFF000000);
		textview17.setTextColor(0xFF000000);
		textview25.setTextColor(0xFF000000);
		textview26.setTextColor(0xFF000000);
		textview22.setTextColor(0xFF000000);
		textview18.setTextColor(0xFF000000);
		imageview2.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview7.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview9.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview11.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview23.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview25.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview19.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview13.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _chromeTab(final String _link) {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#000000"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(MenuActivity.this, Uri.parse(_link));
			} else {
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#FFFFFF"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(MenuActivity.this, Uri.parse(_link));
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#000000"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(MenuActivity.this, Uri.parse(_link));
				
			} else {
				
				// Light mode
				
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#FFFFFF"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(MenuActivity.this, Uri.parse(_link));
			}
		}
	}
	
	
	public void _check_data_() {
		if (d_.contains("user")) {
			data = new Gson().fromJson(d_.getString("user", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			textview1.setText(data.get("first_name").toString());
			textview28.setText(data.get("email").toString());
		} else {
			i_.setClass(getApplicationContext(), AuthActivity.class);
			i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i_);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			finish();
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}