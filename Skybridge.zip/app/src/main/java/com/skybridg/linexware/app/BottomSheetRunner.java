package com.skybridg.linexware.app;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

/**
 * ONE generic runner. Pass it ANY fragment you already built, from ANY activity.
 * The sheet ALWAYS opens at a fixed height (see SHEET_HEIGHT_PERCENT below) —
 * even if the fragment's layout is completely empty, it will not shrink.
 *
 * NO DATA:
 *      BottomSheetRunner.show(DashboardActivity.this, new MenuFragmentActivity());
 *
 * WITH DATA:
 *      MenuFragmentActivity fragment = new MenuFragmentActivity();
 *      Bundle data = new Bundle();
 *      data.putString("name", "Shawn");
 *      fragment.setArguments(data);
 *      BottomSheetRunner.show(DashboardActivity.this, fragment);
 *
 * TO READ THE DATA — inside your own fragment's onCreateView:
 *      String name = getArguments().getString("name");
 */
public class BottomSheetRunner extends BottomSheetDialogFragment {

    // ---- adjust these two to change the look ----
    private static final float SHEET_HEIGHT_PERCENT = 0.9f; // 60% of screen height, always
    private static final int CORNER_RADIUS_DP = 25;

    private static Fragment fragmentToShow;

    public static void show(FragmentActivity activity, Fragment fragment) {
        fragmentToShow = fragment;
        BottomSheetRunner sheet = new BottomSheetRunner();
        sheet.show(activity.getSupportFragmentManager(), "bottom_sheet_runner");
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        // container fills the sheet fully — its own height never shrinks to content
        FrameLayout root = new FrameLayout(requireContext());
        root.setId(View.generateViewId());
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (fragmentToShow != null) {
            getChildFragmentManager()
                    .beginTransaction()
                    .replace(view.getId(), fragmentToShow)
                    .commit();
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = (BottomSheetDialog) super.onCreateDialog(savedInstanceState);
        dialog.setOnKeyListener((d, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                closeSheet();
                return true;
            }
            return false;
        });
        return dialog;
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog == null) return;

        FrameLayout bottomSheet = dialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (bottomSheet == null) return;

        // rounded top corners
        float radiusPx = CORNER_RADIUS_DP * getResources().getDisplayMetrics().density;
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setColor(Color.parseColor("#00000000"));
        bg.setCornerRadii(new float[]{radiusPx, radiusPx, radiusPx, radiusPx, 0, 0, 0, 0});
        bottomSheet.setBackground(bg);

        // force a fixed height no matter what's inside
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int fixedHeight = (int) (screenHeight * SHEET_HEIGHT_PERCENT);

        ViewGroup.LayoutParams params = bottomSheet.getLayoutParams();
        params.height = fixedHeight;
        bottomSheet.setLayoutParams(params);

        BottomSheetBehavior<FrameLayout> behavior = BottomSheetBehavior.from(bottomSheet);
        behavior.setPeekHeight(fixedHeight);
        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        behavior.setSkipCollapsed(true);
    }

    public void closeSheet() {
        if (isAdded()) dismiss();
    }
}
