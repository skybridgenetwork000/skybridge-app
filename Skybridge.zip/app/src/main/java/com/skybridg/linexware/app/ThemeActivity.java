package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;


public class ThemeActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView imageview7;
	private TextView textview13;
	private LinearLayout ck1;
	private ImageView imageview8;
	private TextView textview14;
	private LinearLayout ck2;
	private ImageView imageview9;
	private TextView textview15;
	private LinearLayout ck3;
	
	private SharedPreferences d_;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.theme);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		imageview7 = findViewById(R.id.imageview7);
		textview13 = findViewById(R.id.textview13);
		ck1 = findViewById(R.id.ck1);
		imageview8 = findViewById(R.id.imageview8);
		textview14 = findViewById(R.id.textview14);
		ck2 = findViewById(R.id.ck2);
		imageview9 = findViewById(R.id.imageview9);
		textview15 = findViewById(R.id.textview15);
		ck3 = findViewById(R.id.ck3);
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		
		linear14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d_.edit().putString("theme", "dark").commit();
				_ck(1);
				_theme_();
			}
		});
		
		linear15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d_.edit().putString("theme", "light").commit();
				_ck(2);
				_theme_();
			}
		});
		
		linear16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d_.edit().remove("theme").commit();
				_ck(3);
				_theme_();
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_font_();
		_theme_();
	}
	
	
	@Override
	public void onBackPressed() {
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		finish();
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	public void _font_() {
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview15.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
				_ck(1);
			} else {
				_light_();
				_ck(2);
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
			_ck(3);
		}
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundColor(0xFF000000);
		imageview1.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(18)), 0xFF212121));
		linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		linear15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		linear16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		textview2.setTextColor(0xFFFFFFFF);
		textview13.setTextColor(0xFFFFFFFF);
		textview14.setTextColor(0xFFFFFFFF);
		textview15.setTextColor(0xFFFFFFFF);
		imageview7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		imageview7.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview8.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview9.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		ck1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(100)), 0xFFFFFFFF));
		ck2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(100)), 0xFFFFFFFF));
		ck3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(100)), 0xFFFFFFFF));
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundColor(0xFFFFFFFF);
		imageview1.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(18)), 0xFFEEEEEE));
		linear14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		linear15.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		linear16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		textview2.setTextColor(0xFF000000);
		textview13.setTextColor(0xFF000000);
		textview14.setTextColor(0xFF000000);
		textview15.setTextColor(0xFF000000);
		imageview7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		imageview7.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview8.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview9.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		ck1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(100)), 0xFF000000));
		ck2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(100)), 0xFF000000));
		ck3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(100)), 0xFF000000));
	}
	
	
	public void _ck(final double _id) {
		if (_id == 1) {
			ck1.setVisibility(View.VISIBLE);
		} else {
			ck1.setVisibility(View.INVISIBLE);
		}
		if (_id == 2) {
			ck2.setVisibility(View.VISIBLE);
		} else {
			ck2.setVisibility(View.INVISIBLE);
		}
		if (_id == 3) {
			ck3.setVisibility(View.VISIBLE);
		} else {
			ck3.setVisibility(View.INVISIBLE);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}