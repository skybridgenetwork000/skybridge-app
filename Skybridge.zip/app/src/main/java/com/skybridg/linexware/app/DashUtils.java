package com.skybridg.linexware.app;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.Shape;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.TextView;

public class DashUtils {

    // Dashed underline under a TextView - drawn as foreground, background untouched
    public static void setDashedUnderline(TextView tv, int color, float strokeWidthPx, float dashWidth, float dashGap) {
        ShapeDrawable drawable = new ShapeDrawable(new Shape() {
            @Override
            public void draw(Canvas canvas, Paint paint) {
                canvas.drawLine(0, getHeight() - 1, getWidth(), getHeight() - 1, paint);
            }
        });
        Paint p = drawable.getPaint();
        p.setColor(color);
        p.setStrokeWidth(strokeWidthPx);
        p.setStyle(Paint.Style.STROKE);
        p.setPathEffect(new DashPathEffect(new float[]{dashWidth, dashGap}, 0));
        tv.setPadding(tv.getPaddingLeft(), tv.getPaddingTop(), tv.getPaddingRight(), (int) strokeWidthPx + 4);
        tv.setForeground(drawable);
    }

    // Dashed border/stroke around any View - drawn as foreground, background (color/image) untouched.
    // Also clips the view's own contents to the same corner radius, so children can't stick out
    // past rounded corners (same behavior as CardView).
    // cornerRadiusPx is a double so it accepts Sketchware "number" (double) variables directly,
    // no cast needed at the call site.
    public static void setDashedStroke(View view, int color, int strokeWidthPx, float dashWidth, float dashGap, double cornerRadiusPx) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.TRANSPARENT);
        gd.setStroke(strokeWidthPx, color, dashWidth, dashGap);
        gd.setCornerRadius((float) cornerRadiusPx);
        view.setForeground(gd);

        setRoundedClip(view, (float) cornerRadiusPx);
    }

    // Clips a View's contents (e.g. LinearLayout children, ImageViews, etc.) to a rounded-rect
    // outline, matching cornerRadiusPx. Call this alone if you just need clipping without a stroke.
    public static void setRoundedClip(View view, float cornerRadiusPx) {
        view.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), cornerRadiusPx);
            }
        });
        view.setClipToOutline(true);
    }
}