package com.skybridg.linexware.app;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.PictureDrawable;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import com.caverock.androidsvg.SVG;
import com.caverock.androidsvg.SVGParseException;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;

public class SvgView {
		
		public void nopull( String v){
				
		}
	
		public static void GetFileSvg(String input, ImageView img) {
		
				try {
			
						File startDir = new File(input);
						FileInputStream fileInputStream = new FileInputStream(startDir);
			
						SVG svg = SVG.getFromInputStream(fileInputStream);
						Drawable drawable = new PictureDrawable(svg.renderToPicture());
						img.setImageDrawable(drawable);
			
				} catch (IOException d) {
						d.printStackTrace();
			
				} catch (SVGParseException s) {
						s.printStackTrace();
			
				} catch (Exception exception) {
			
						exception.printStackTrace();
				}
		
		}
	
		public static void GetAsster(Context context, ImageView img, String input) {
				try {
			
						SVG ss = SVG.getFromAsset(context.getAssets(), input);
						Drawable d = new PictureDrawable(ss.renderToPicture());
						img.setImageDrawable(d);
			
				} catch (Exception exn) {
			
						exn.printStackTrace();
			
				}
		
		}
	
}