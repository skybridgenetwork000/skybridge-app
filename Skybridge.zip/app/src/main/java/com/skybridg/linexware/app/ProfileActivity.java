package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;

public class ProfileActivity extends AppCompatActivity {
	
	private HashMap<String, Object> data = new HashMap<>();
	private String account_id = "";
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout linear18;
	private LinearLayout linear5;
	private LinearLayout linear8;
	private LinearLayout linear13;
	private LinearLayout linear6;
	private LinearLayout linear3;
	private LinearLayout linear7;
	private TextView textview5;
	private TextView textview6;
	private LinearLayout linear4;
	private TextView textview4;
	private TextView textview3;
	private LinearLayout linear9;
	private LinearLayout linear12;
	private TextView textview9;
	private TextView textview10;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private LinearLayout linear17;
	private TextView textview13;
	private ImageView imageview2;
	private TextView textview14;
	private LinearLayout linear16;
	private TextView textview11;
	private TextView textview12;
	
	private SharedPreferences d_;
	private Intent i_ = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		linear18 = findViewById(R.id.linear18);
		linear5 = findViewById(R.id.linear5);
		linear8 = findViewById(R.id.linear8);
		linear13 = findViewById(R.id.linear13);
		linear6 = findViewById(R.id.linear6);
		linear3 = findViewById(R.id.linear3);
		linear7 = findViewById(R.id.linear7);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		linear4 = findViewById(R.id.linear4);
		textview4 = findViewById(R.id.textview4);
		textview3 = findViewById(R.id.textview3);
		linear9 = findViewById(R.id.linear9);
		linear12 = findViewById(R.id.linear12);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		linear17 = findViewById(R.id.linear17);
		textview13 = findViewById(R.id.textview13);
		imageview2 = findViewById(R.id.imageview2);
		textview14 = findViewById(R.id.textview14);
		linear16 = findViewById(R.id.linear16);
		textview11 = findViewById(R.id.textview11);
		textview12 = findViewById(R.id.textview12);
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", account_id));
				CustomToast.showSuccess(ProfileActivity.this, "Copied", "Account ID copied successfully!!");
			}
		});
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_font_();
		_theme_();
		_check_data_();
		vscroll1.setVerticalScrollBarEnabled(false); vscroll1.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Override
	public void onBackPressed() {
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		finish();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	public void _font_() {
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
			} else {
				_light_();
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
		}
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundColor(0xFF000000);
		imageview1.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(18)), 0xFF212121));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		textview4.setTextColor(0xFFFFFFFF);
		textview5.setTextColor(0xFFFFFFFF);
		textview9.setTextColor(0xFFFFFFFF);
		textview13.setTextColor(0xFFFFFFFF);
		textview2.setTextColor(0xFFFFFFFF);
		imageview2.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundColor(0xFFFFFFFF);
		imageview1.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(18)), 0xFFEEEEEE));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		textview4.setTextColor(0xFF000000);
		textview5.setTextColor(0xFF000000);
		textview9.setTextColor(0xFF000000);
		textview13.setTextColor(0xFF000000);
		textview2.setTextColor(0xFF000000);
		imageview2.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _check_data_() {
		if (d_.contains("user")) {
			data = new Gson().fromJson(d_.getString("user", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			textview5.setText(data.get("first_name").toString());
			textview4.setText(data.get("last_name").toString());
			textview9.setText(data.get("email").toString());
			account_id = data.get("account_id").toString();
			textview13.setText(data.get("account_id").toString());
			if (data.get("kyc").toString().equals("true")) {
				textview11.setText("Verified");
				textview11.setTextColor(0xFF4CAF50);
				textview11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0x2000E676));
			} else {
				if (data.get("kyc").toString().equals("false")) {
					textview11.setText("Unverified");
					textview11.setTextColor(0xFFF44336);
					textview11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0x10F44336));
				} else {
					if (data.get("kyc").toString().equals("pending")) {
						textview11.setText("Pending");
						textview11.setTextColor(0xFF2196F3);
						textview11.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0x102196FE));
					}
				}
			}
		} else {
			i_.setClass(getApplicationContext(), AuthActivity.class);
			i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i_);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			finish();
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}