package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.skybridg.linexware.app.LottieSwipeRefreshLayout;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;

public class DashboardActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String st_ = "";
	private String lt_ = "";
	private double text_ = 0;
	private double rad = 0;
	private HashMap<String, Object> data = new HashMap<>();
	private HashMap<String, Object> map_H = new HashMap<>();
	private HashMap<String, Object> map_D = new HashMap<>();
	private HashMap<String, Object> m_1 = new HashMap<>();
	private HashMap<String, Object> m_2 = new HashMap<>();
	private LottieSwipeRefreshLayout layout;
	
	private ArrayList<String> images = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LottieSwipeRefreshLayout swipe;
	private LinearLayout linear23;
	private ImageView imageview2;
	private TextView textview24;
	private ScrollView vscroll1;
	private LinearLayout linear6;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private LinearLayout linCaro;
	private LinearLayout linear24;
	private TextView textview27;
	private LinearLayout linear26;
	private LinearLayout linear3;
	private LinearLayout linear11;
	private LinearLayout linear9;
	private TextView textview5;
	private LinearLayout line;
	private LinearLayout linear10;
	private TextView textview7;
	private TextView textview6;
	private LinearLayout linear4;
	private ImageView visible_hide_icon;
	private TextView balance_big_text;
	private TextView balance_small_text;
	private TextView textview4;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private TextView current_price_text;
	private TextView textview10;
	private TextView total_supply_text;
	private TextView textview12;
	private TextView textview13;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private TextView textview17;
	private TextView mining_rate;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private TextView mining_button_text;
	private TextView current_mining_count;
	private TextView textview23;
	private LinearLayout linear25;
	private TextView text;
	private TextView textview26;
	private ImageView imageview4;
	private ImageView imageview5;
	private ImageView imageview6;
	private ImageView imageview7;
	
	private TimerTask t_;
	private Intent i_ = new Intent();
	private SharedPreferences d_;
	private RequestNetwork rq_;
	private RequestNetwork.RequestListener _rq__request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dashboard);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		swipe = findViewById(R.id.swipe);
		linear23 = findViewById(R.id.linear23);
		imageview2 = findViewById(R.id.imageview2);
		textview24 = findViewById(R.id.textview24);
		vscroll1 = findViewById(R.id.vscroll1);
		linear6 = findViewById(R.id.linear6);
		linear5 = findViewById(R.id.linear5);
		linear7 = findViewById(R.id.linear7);
		linCaro = findViewById(R.id.linCaro);
		linear24 = findViewById(R.id.linear24);
		textview27 = findViewById(R.id.textview27);
		linear26 = findViewById(R.id.linear26);
		linear3 = findViewById(R.id.linear3);
		linear11 = findViewById(R.id.linear11);
		linear9 = findViewById(R.id.linear9);
		textview5 = findViewById(R.id.textview5);
		line = findViewById(R.id.line);
		linear10 = findViewById(R.id.linear10);
		textview7 = findViewById(R.id.textview7);
		textview6 = findViewById(R.id.textview6);
		linear4 = findViewById(R.id.linear4);
		visible_hide_icon = findViewById(R.id.visible_hide_icon);
		balance_big_text = findViewById(R.id.balance_big_text);
		balance_small_text = findViewById(R.id.balance_small_text);
		textview4 = findViewById(R.id.textview4);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		current_price_text = findViewById(R.id.current_price_text);
		textview10 = findViewById(R.id.textview10);
		total_supply_text = findViewById(R.id.total_supply_text);
		textview12 = findViewById(R.id.textview12);
		textview13 = findViewById(R.id.textview13);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		textview17 = findViewById(R.id.textview17);
		mining_rate = findViewById(R.id.mining_rate);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		mining_button_text = findViewById(R.id.mining_button_text);
		current_mining_count = findViewById(R.id.current_mining_count);
		textview23 = findViewById(R.id.textview23);
		linear25 = findViewById(R.id.linear25);
		text = findViewById(R.id.text);
		textview26 = findViewById(R.id.textview26);
		imageview4 = findViewById(R.id.imageview4);
		imageview5 = findViewById(R.id.imageview5);
		imageview6 = findViewById(R.id.imageview6);
		imageview7 = findViewById(R.id.imageview7);
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		rq_ = new RequestNetwork(this);
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i_.setClass(getApplicationContext(), MenuActivity.class);
				i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_);
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		});
		
		linear25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				android.transition.TransitionManager.beginDelayedTransition((LinearLayout)linear1, new android.transition.AutoTransition());
				if (text_ == 0) {
					text.setText(lt_);
					imageview4.setRotation((float)(180));
					text_ = 1;
				} else {
					text.setText(st_);
					imageview4.setRotation((float)(0));
					text_ = 0;
				}
			}
		});
		
		_rq__request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_loading(false);
				layout.setRefreshing(false);
				if (_tag.equals("FU")) {
					try {
						m_1 = new Gson().fromJson(_response, HashMap.class);
						if (m_1.get("status").toString().equals("success")) {
							m_2 = new HashMap<>();
							m_2.putAll((Map) m_1.get("data"));
							d_.edit().putString("user", new Gson().toJson(m_2.get("user"))).commit();
							d_.edit().putString("backup", new Gson().toJson(m_2.get("backup"))).commit();
							_check_data_();
						} else {
							CustomToast.showError(DashboardActivity.this, "Response Error", m_1.get("message").toString());
						}
					} catch (Exception e) {
						CustomToast.showError(DashboardActivity.this, "Response Error", "Couldn't Refresh!!");
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				_loading(false);
				layout.setRefreshing(false);
				CustomToast.showError(DashboardActivity.this, "Connection Error", "Connection failed, please check your Internet or wifi.");
			}
		};
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_ui_();
		_font_();
		_theme_();
		_check_data_();
		android.transition.TransitionManager.beginDelayedTransition((LinearLayout)linear1, new android.transition.AutoTransition());
		vscroll1.setVerticalScrollBarEnabled(false); vscroll1.setHorizontalScrollBarEnabled(false);
		st_ = "Welcome to SkyBridge Network, \n\na community driven crypto ecosystem built to make digital assets more accessible, transparent, and rewarding for everyone.\n\n Our mission is to combine the power of artificial intelligence with blockchain innovation to create a smarter and fairer mining experience where every member has the opportunity to participate in the growth of the network.";
		lt_ = "Welcome to SkyBridge Network, \n\na community driven crypto ecosystem built to make digital assets more accessible, transparent, and rewarding for everyone.\n\n Our mission is to combine the power of artificial intelligence with blockchain innovation to create a smarter and fairer mining experience where every member has the opportunity to participate in the growth of the network.\n\nSkyBridge is more than a mining application. It is a growing digital community designed around trust, transparency, and long term sustainability. We believe cryptocurrency should be simple to understand and available to everyone, regardless of experience. By using intelligent technologies and a user focused approach, we are building a platform that removes unnecessary complexity while creating a secure environment for our global community.\n\nAs the SkyBridge ecosystem continues to evolve, members will gain access to exciting features, community events, ecosystem rewards, and future utilities that support the growth of the network. Our native community coin is currently under development, and we are working towards the launch of our mainnet with a strong focus on security, reliability, and decentralization. Every contribution from our community helps shape the future of the project.\n\nOur vision is to build a next generation social cryptocurrency that is powered by its community and strengthened through innovation. Together, we are creating a network where technology, transparency, and collaboration come together to unlock new opportunities in the digital economy.\n\nThank you for joining SkyBridge Network. This is only the beginning of an exciting journey toward a smarter, more connected, and community powered future of cryptocurrency. Together, we are building the bridge to the next generation of digital finance.";
		text.setText(st_);
		imageview4.setRotation((float)(0));
		text_ = 0;
		images.add("https://skybridge.linexware.net.ng/images/file_00000000793481f491934f4f2b9b976c%20%281%29.png");
		images.add("https://skybridge.linexware.net.ng/images/file_00000000ceec820a85df2c0a6f233727.png");
		new AutoCarousel(DashboardActivity.this, linCaro, images)
		.setCornerRadius(20)
		.setPlaceholder(R.drawable.carousel_im)
		.start();
		layout = findViewById(R.id.swipe);
		layout.setOnRefreshListener(() -> {
			// your refresh work
			
			
			t_ = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							if (d_.contains("authentication")) {
								_fetch_account(d_.getString("authentication", ""));
							} else {
								i_.setClass(getApplicationContext(), AuthActivity.class);
								i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i_);
								overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
								finish();
							}
						}
					});
				}
			};
			_timer.schedule(t_, (int)(2000));
		});
	}
	
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	public void _ui_() {
		
	}
	
	
	public void _font_() {
		balance_big_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		balance_small_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		current_price_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		total_supply_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		current_price_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview17.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		mining_rate.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		current_mining_count.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview23.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		mining_button_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
		textview24.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		textview26.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_sb.ttf"), 0);
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
			} else {
				_light_();
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
		}
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundColor(0xFF000000);
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		textview6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0x2000E676));
		linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF0E0E0E));
		linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF0E0E0E));
		linear19.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF212121));
		textview13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0xFF212121));
		linear24.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFF212121));
		text.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF0E0E0E));
		mining_button_text.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF0E0E0E));
		DashUtils.setDashedStroke(linear7, Color.parseColor("#212121"), 3, 15f, 6f, SketchwareUtil.getDip(getApplicationContext(), (int)(20)));
		line.setBackgroundColor(0xFF000000);
		imageview2.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
		imageview4.setColorFilter(0xFFEEEEEE, PorterDuff.Mode.MULTIPLY);
		visible_hide_icon.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		textview24.setTextColor(0xFFE0E0E0);
		textview27.setTextColor(0xFFBDBDBD);
		textview5.setTextColor(0xFFE0E0E0);
		textview7.setTextColor(0xFFEEEEEE);
		balance_big_text.setTextColor(0xFFFFFFFF);
		balance_small_text.setTextColor(0xFF9E9E9E);
		textview4.setTextColor(0xFFBDBDBD);
		current_price_text.setTextColor(0xFFE0E0E0);
		textview10.setTextColor(0xFF757575);
		total_supply_text.setTextColor(0xFFE0E0E0);
		textview12.setTextColor(0xFF757575);
		textview13.setTextColor(0xFFE0E0E0);
		textview17.setTextColor(0xFF9E9E9E);
		mining_rate.setTextColor(0xFFE0E0E0);
		mining_button_text.setTextColor(0xFFEEEEEE);
		current_mining_count.setTextColor(0xFFE0E0E0);
		textview23.setTextColor(0xFF757575);
		text.setTextColor(0xFFE0E0E0);
		textview26.setTextColor(0xFFEEEEEE);
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundColor(0xFFFFFFFF);
		linear3.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		textview6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0x2000E676));
		linear12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		linear13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		linear19.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFEEEEEE));
		textview13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(10)), 0xFFEEEEEE));
		linear24.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(20)), 0xFFEEEEEE));
		text.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFFFFFFF));
		mining_button_text.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		DashUtils.setDashedStroke(linear7, Color.parseColor("#e0e0e0"), 3, 15f, 6f, SketchwareUtil.getDip(getApplicationContext(), (int)(20)));
		line.setBackgroundColor(0xFFE0E0E0);
		imageview2.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview4.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		visible_hide_icon.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		textview24.setTextColor(0xFF000000);
		textview27.setTextColor(0xFF212121);
		textview5.setTextColor(0xFF0E0E0E);
		textview7.setTextColor(0xFF000000);
		balance_big_text.setTextColor(0xFF000000);
		balance_small_text.setTextColor(0xFF757575);
		textview4.setTextColor(0xFF757575);
		current_price_text.setTextColor(0xFF000000);
		textview10.setTextColor(0xFF9E9E9E);
		total_supply_text.setTextColor(0xFF000000);
		textview12.setTextColor(0xFF9E9E9E);
		textview13.setTextColor(0xFF0E0E0E);
		textview17.setTextColor(0xFF9E9E9E);
		mining_rate.setTextColor(0xFF0E0E0E);
		mining_button_text.setTextColor(0xFFFFFFFF);
		current_mining_count.setTextColor(0xFF0E0E0E);
		textview23.setTextColor(0xFF9E9E9E);
		text.setTextColor(0xFF616161);
		textview26.setTextColor(0xFF000000);
	}
	
	
	public void _set_balance_(final String _balance) {
		String input = _balance; // your value, e.g. from balance
		int decimalLimit = 3; // how many decimal digits you want to keep
		
		String wholePart = "";
		String decimalPart = "";
		
		if (input.contains(".")) {
			wholePart = input.substring(0, input.indexOf("."));
			decimalPart = input.substring(input.indexOf("."));
			if (decimalPart.length() - 1 > decimalLimit) {
				decimalPart = decimalPart.substring(0, decimalLimit + 1); // +1 to include the dot
			}
		} else {
			wholePart = input;
		}
		
		balance_big_text.setText(wholePart);
		balance_small_text.setText(decimalPart);
	}
	
	
	public void _check_data_() {
		if (d_.contains("backup")) {
			data = new Gson().fromJson(d_.getString("backup", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			_set_balance_(data.get("balance").toString());
		} else {
			i_.setClass(getApplicationContext(), AuthActivity.class);
			i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(i_);
			overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			finish();
		}
	}
	
	
	public void _fetch_account(final String _id) {
		map_H = new HashMap<>();
		map_H.put("Content-Type", "application/x-www-form-urlencoded");
		rq_.setHeaders(map_H);
		map_D = new HashMap<>();
		map_D.put("search", _id);
		rq_.setParams(map_D, RequestNetworkController.REQUEST_PARAM);
		rq_.startRequestNetwork(RequestNetworkController.POST, d_.getString("server-url", "").concat("fetch-user.php"), "FU", _rq__request_listener);
	}
	
	
	public void _loading(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}