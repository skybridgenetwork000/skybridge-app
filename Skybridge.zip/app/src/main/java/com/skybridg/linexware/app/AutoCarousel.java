package com.skybridg.linexware.app;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.core.graphics.drawable.RoundedBitmapDrawable;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;

import org.json.JSONArray;

import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * AutoCarousel
 * ------------
 * Drop-in auto-scrolling image carousel. Works from an Activity, a Fragment,
 * or a Dialog — it only ever needs a Context + a LinearLayout.
 *
 *   new AutoCarousel(context, linear1, images)
 *          .setCornerRadius(24)
 *          .setInterval(3500)
 *          .setPlaceholder(R.drawable.carousel_image)
 *          .setDotColors(Color.BLACK, Color.parseColor("#FEFEFE"))
 *          .start();
 *
 * The user can also swipe left/right to browse manually — auto-scroll pauses
 * during the swipe and resumes on its own timer from wherever the user left it,
 * it never jumps back to a fixed slide.
 *
 * If an image fails to load (e.g. no internet when the app opened), it's
 * remembered and automatically retried the moment the device reconnects.
 *
 * IMPORTANT: your project needs the INTERNET permission for URL images to load,
 * and ACCESS_NETWORK_STATE for the auto-retry to detect reconnects
 * (Sketchware Pro -> Project Settings -> Permissions).
 *
 * Always call .stop() when the screen goes away:
 *   Activity  -> onDestroy()
 *   Fragment  -> onDestroyView()
 *   Dialog    -> setOnDismissListener
 */
public class AutoCarousel {

    private final Context context;
    private final WeakReference<LinearLayout> containerRef;
    private final List<String> imageUrls;

    private int cornerRadiusPx;
    private int intervalMs = 3000;

    private int activeDotColor = Color.BLACK;
    private int inactiveDotColor = Color.parseColor("#FEFEFE");
    private final int dotBorderColor = Color.parseColor("#E0E0E0");

    private int placeholderResId = 0;

    private FrameLayout root;
    private View dotsRow; // kept as a direct reference so z-ordering never gets confused
    private final List<ImageView> slides = new ArrayList<>();
    private final List<View> dotViews = new ArrayList<>();
    private final List<GradientDrawable> dotDrawables = new ArrayList<>();

    private int currentIndex = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService loader = Executors.newFixedThreadPool(2);
    private volatile boolean running = false;

    private final Map<ImageView, String> failedLoads = new ConcurrentHashMap<>();
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    private GestureDetector gestureDetector;

    private final Runnable autoAdvance = new Runnable() {
        @Override
        public void run() {
            LinearLayout container = containerRef.get();
            if (!running || container == null || !container.isAttachedToWindow()
                    || imageUrls.isEmpty() || root == null) {
                return; // screen is gone or stopped — quietly do nothing, no crash
            }
            int nextIndex = (currentIndex + 1) % imageUrls.size();
            transitionTo(nextIndex, true);
            animateDots(nextIndex);
            currentIndex = nextIndex;
            handler.postDelayed(this, intervalMs);
        }
    };

    public AutoCarousel(Context context, LinearLayout container, List<String> imageUrls) {
        this.context = context;
        this.containerRef = new WeakReference<>(container);
        this.imageUrls = imageUrls != null ? imageUrls : new ArrayList<String>();
        this.cornerRadiusPx = dp(16);
    }

    // ---------- public config (chainable) ----------

    public AutoCarousel setCornerRadius(int dp) {
        this.cornerRadiusPx = dp(dp);
        return this;
    }

    public AutoCarousel setInterval(int ms) {
        this.intervalMs = ms;
        return this;
    }

    public AutoCarousel setDotColors(int activeColor, int inactiveColor) {
        this.activeDotColor = activeColor;
        this.inactiveDotColor = inactiveColor;
        return this;
    }

    public AutoCarousel setPlaceholder(int drawableResId) {
        this.placeholderResId = drawableResId;
        return this;
    }

    public static List<String> parseUrls(String json) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                out.add(arr.getString(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return out;
    }

    /** Manually go to the next slide (same as a left swipe). Auto-scroll resumes from here. */
    public void goToNext() {
        if (imageUrls.size() < 2) return;
        int nextIndex = (currentIndex + 1) % imageUrls.size();
        manualAdvance(nextIndex, true);
    }

    /** Manually go to the previous slide (same as a right swipe). Auto-scroll resumes from here. */
    public void goToPrevious() {
        if (imageUrls.size() < 2) return;
        int prevIndex = (currentIndex - 1 + imageUrls.size()) % imageUrls.size();
        manualAdvance(prevIndex, false);
    }

    // ---------- build + start ----------

    public AutoCarousel start() {
        LinearLayout container = containerRef.get();
        if (container == null) return this;

        container.removeAllViews();
        slides.clear();
        dotViews.clear();
        dotDrawables.clear();
        failedLoads.clear();
        currentIndex = 0;

        root = new FrameLayout(context);
        root.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        for (int i = 0; i < imageUrls.size(); i++) {
            String url = imageUrls.get(i);
            ImageView iv = new ImageView(context);
            iv.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setClipToOutline(true);
            iv.setBackground(roundedOutlineDrawable(cornerRadiusPx));

            if (placeholderResId != 0) {
                iv.setImageResource(placeholderResId);
            }

            iv.setAlpha(i == 0 ? 1f : 0f);

            root.addView(iv);
            slides.add(iv);
            loadImageAsync(url, iv);
        }

        // dots row, bottom-center
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams dotsParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dotsParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        dotsParams.bottomMargin = dp(12);
        row.setLayoutParams(dotsParams);

        for (int i = 0; i < imageUrls.size(); i++) {
            View dot = new View(context);
            boolean isActive = (i == 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    isActive ? dp(20) : dp(7), dp(7));
            lp.setMargins(dp(3), 0, dp(3), 0);
            dot.setLayoutParams(lp);

            GradientDrawable gd = new GradientDrawable();
            gd.setShape(GradientDrawable.RECTANGLE);
            gd.setCornerRadius(dp(10));
            gd.setColor(isActive ? activeDotColor : inactiveDotColor);
            gd.setStroke(dp(1), dotBorderColor);
            dot.setBackground(gd);

            row.addView(dot);
            dotViews.add(dot);
            dotDrawables.add(gd);
        }
        root.addView(row);
        dotsRow = row;

        container.addView(root);

        running = true;
        handler.removeCallbacks(autoAdvance);
        handler.postDelayed(autoAdvance, intervalMs);
        registerConnectivityRetry();
        setupSwipeGestures();
        return this;
    }

    /** Always safe to call more than once, and safe to call even if the screen is already gone. */
    public void stop() {
        running = false;
        handler.removeCallbacks(autoAdvance);
        if (connectivityManager != null && networkCallback != null) {
            try {
                connectivityManager.unregisterNetworkCallback(networkCallback);
            } catch (Exception ignored) {
                // already unregistered or never registered — safe to ignore
            }
        }
    }

    // ---------- manual swipe ----------

    private void setupSwipeGestures() {
        final int swipeDistanceThreshold = dp(40);
        final int swipeVelocityThreshold = dp(60);

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null) return false;
                float diffX = e2.getX() - e1.getX();
                float diffY = e2.getY() - e1.getY();
                if (Math.abs(diffX) > Math.abs(diffY)
                        && Math.abs(diffX) > swipeDistanceThreshold
                        && Math.abs(velocityX) > swipeVelocityThreshold) {
                    if (diffX < 0) {
                        goToNext();     // swiped left -> next slide
                    } else {
                        goToPrevious(); // swiped right -> previous slide
                    }
                    return true;
                }
                return false;
            }
        });

        // returns false for anything that isn't a recognised horizontal swipe, so this
        // won't block an outer vertical ScrollView the LinearLayout might be sitting inside
        root.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        });
    }

    private void manualAdvance(int targetIndex, boolean forward) {
        handler.removeCallbacks(autoAdvance); // pause the auto-timer during the manual move
        transitionTo(targetIndex, forward);
        animateDots(targetIndex);
        currentIndex = targetIndex;
        if (running) {
            handler.postDelayed(autoAdvance, intervalMs); // resume counting down from here, not from slide 0
        }
    }

    // ---------- auto-retry when internet reconnects ----------

    private void registerConnectivityRetry() {
        try {
            connectivityManager = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (connectivityManager == null) return;

            NetworkRequest request = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();

            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    retryFailedLoads();
                }
            };
            connectivityManager.registerNetworkCallback(request, networkCallback);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void retryFailedLoads() {
        if (failedLoads.isEmpty() || !running) return;
        final Map<ImageView, String> snapshot = new HashMap<>(failedLoads);
        failedLoads.clear();
        handler.post(new Runnable() {
            @Override
            public void run() {
                for (Map.Entry<ImageView, String> entry : snapshot.entrySet()) {
                    ImageView iv = entry.getKey();
                    if (iv.getWindowToken() == null) continue;
                    loadImageAsync(entry.getValue(), iv);
                }
            }
        });
    }

    // ---------- scale + slide + fade transition (corners preserved throughout) ----------

    /**
     * @param forward true = incoming enters from the right, outgoing exits left (next slide)
     *                false = incoming enters from the left, outgoing exits right (previous slide)
     */
    private void transitionTo(final int nextIndex, boolean forward) {
        final ImageView outgoing = slides.get(currentIndex);
        final ImageView incoming = slides.get(nextIndex);
        if (outgoing == incoming) return;

        incoming.bringToFront();
        if (dotsRow != null) {
            dotsRow.bringToFront();
        }
        root.requestLayout();
        root.invalidate();

        float width = root.getWidth();
        if (width <= 0) width = 1000f; // safety fallback before first layout pass

        float startOffset = forward ? width * 0.28f : -width * 0.28f;
        float endOffset = forward ? -width * 0.28f : width * 0.28f;

        incoming.setAlpha(0f);
        incoming.setScaleX(0.8f);
        incoming.setScaleY(0.8f);
        incoming.setTranslationX(startOffset);

        incoming.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationX(0f)
                .setDuration(600)
                .setInterpolator(new OvershootInterpolator(0.8f))
                .start();

        outgoing.animate()
                .alpha(0f)
                .scaleX(0.8f)
                .scaleY(0.8f)
                .translationX(endOffset)
                .setDuration(600)
                .setInterpolator(new AccelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        outgoing.setScaleX(1f);
                        outgoing.setScaleY(1f);
                        outgoing.setTranslationX(0f);
                    }
                })
                .start();
    }

    // ---------- bouncy dot indicator animation ----------

    private void animateDots(int activeIndex) {
        for (int i = 0; i < dotViews.size(); i++) {
            boolean toActive = (i == activeIndex);
            animateSingleDot(dotViews.get(i), dotDrawables.get(i), toActive);
        }
    }

    private void animateSingleDot(final View dot, final GradientDrawable gd, final boolean toActive) {
        final LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) dot.getLayoutParams();
        int fromWidth = lp.width;
        int toWidth = toActive ? dp(20) : dp(7);
        int fromColor = toActive ? inactiveDotColor : activeDotColor;
        int toColor = toActive ? activeDotColor : inactiveDotColor;

        if (fromWidth == toWidth) return;

        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(380);
        anim.setInterpolator(new OvershootInterpolator(2.5f));
        final ArgbEvaluator colorEvaluator = new ArgbEvaluator();

        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float fraction = animation.getAnimatedFraction();
                float value = (float) animation.getAnimatedValue();

                int newWidth = Math.round(fromWidth + (toWidth - fromWidth) * value);
                if (newWidth > 0) {
                    lp.width = newWidth;
                    dot.setLayoutParams(lp);
                }

                int blendedColor = (int) colorEvaluator.evaluate(fraction, fromColor, toColor);
                gd.setColor(blendedColor);
            }
        });
        anim.start();
    }

    // ---------- internals ----------

    private GradientDrawable roundedOutlineDrawable(int radiusPx) {
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.RECTANGLE);
        gd.setCornerRadius(radiusPx);
        gd.setColor(Color.parseColor("#1AFFFFFF"));
        return gd;
    }

    private void loadImageAsync(final String url, final ImageView target) {
        loader.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    URL u = new URL(url);
                    conn = (HttpURLConnection) u.openConnection();
                    conn.setRequestProperty("User-Agent",
                            "Mozilla/5.0 (Android) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36");
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);
                    conn.setInstanceFollowRedirects(true);
                    conn.connect();

                    int code = conn.getResponseCode();
                    if (code != HttpURLConnection.HTTP_OK) {
                        failedLoads.put(target, url);
                        return;
                    }

                    InputStream in = conn.getInputStream();
                    final Bitmap bmp = BitmapFactory.decodeStream(in);
                    in.close();
                    if (bmp == null) {
                        failedLoads.put(target, url);
                        return;
                    }
                    if (!running) return;

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (target.getWindowToken() == null) return;
                            RoundedBitmapDrawable rd = RoundedBitmapDrawableFactory.create(
                                    context.getResources(), bmp);
                            rd.setCornerRadius(cornerRadiusPx);
                            target.setImageDrawable(rd);
                        }
                    });
                } catch (Exception e) {
                    failedLoads.put(target, url);
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        });
    }

    private int dp(int value) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
