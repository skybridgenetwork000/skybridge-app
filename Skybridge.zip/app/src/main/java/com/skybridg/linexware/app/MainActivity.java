package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> map_H = new HashMap<>();
	private HashMap<String, Object> map_D = new HashMap<>();
	private HashMap<String, Object> m_1 = new HashMap<>();
	private HashMap<String, Object> m_2 = new HashMap<>();
	
	private LinearLayout linear1;
	private ImageView splash_image;
	
	private Intent i_ = new Intent();
	private TimerTask t_;
	private SharedPreferences d_;
	private RequestNetwork rq_;
	private RequestNetwork.RequestListener _rq__request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		splash_image = findViewById(R.id.splash_image);
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		rq_ = new RequestNetwork(this);
		
		_rq__request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				try {
					m_1 = new Gson().fromJson(_response, HashMap.class);
					if (m_1.get("status").toString().equals("success")) {
						m_2 = new HashMap<>();
						m_2.putAll((Map) m_1.get("data"));
						d_.edit().putString("user", new Gson().toJson(m_2.get("user"))).commit();
						d_.edit().putString("backup", new Gson().toJson(m_2.get("backup"))).commit();
						i_.setClass(getApplicationContext(), DashboardActivity.class);
						i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i_);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
					} else {
						i_.setClass(getApplicationContext(), AuthActivity.class);
						i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i_);
						overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						finish();
					}
				} catch (Exception e) {
					i_.setClass(getApplicationContext(), AuthActivity.class);
					i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i_);
					overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
					finish();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				t_ = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (d_.contains("authentication")) {
									_fetch_account(d_.getString("authentication", ""));
								} else {
									i_.setClass(getApplicationContext(), AuthActivity.class);
									i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
									startActivity(i_);
									overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
									finish();
								}
							}
						});
					}
				};
				_timer.schedule(t_, (int)(2000));
			}
		};
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_ui_();
		_font_();
		_config_();
		t_ = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (d_.contains("authentication")) {
							_fetch_account(d_.getString("authentication", ""));
						} else {
							i_.setClass(getApplicationContext(), AuthActivity.class);
							i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i_);
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
							finish();
						}
					}
				});
			}
		};
		_timer.schedule(t_, (int)(3000));
	}
	
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	public void _ui_() {
		
	}
	
	
	public void _font_() {
		
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
			} else {
				_light_();
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
		}
	}
	
	
	public void _config_() {
		d_.edit().putString("server-url", "https://skybridge.linexware.net.ng/api/").commit();
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundColor(0xFF000000);
		splash_image.setImageResource(R.drawable.icc_1);
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundColor(0xFFFFFFFF);
		splash_image.setImageResource(R.drawable.icc_2);
	}
	
	
	public void _fetch_account(final String _id) {
		map_H = new HashMap<>();
		map_H.put("Content-Type", "application/x-www-form-urlencoded");
		rq_.setHeaders(map_H);
		map_D = new HashMap<>();
		map_D.put("search", _id);
		rq_.setParams(map_D, RequestNetworkController.REQUEST_PARAM);
		rq_.startRequestNetwork(RequestNetworkController.POST, d_.getString("server-url", "").concat("fetch-user.php"), "", _rq__request_listener);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}