package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import android.net.Uri;
import android.graphics.Color;

public class AuthActivity extends AppCompatActivity {
	
	public final int REQ_CD_G_ = 101;
	
	private String token_ = "";
	GoogleSignInOptions options;
	private HashMap<String, Object> map_H = new HashMap<>();
	private HashMap<String, Object> map_D = new HashMap<>();
	private HashMap<String, Object> m_1 = new HashMap<>();
	private HashMap<String, Object> m_2 = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear8;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear7;
	private TextView textview3;
	private ImageView imageview1;
	private TextView textview2;
	private LinearLayout linear5;
	private TextView textview6;
	private LinearLayout linear6;
	private ImageView imageview2;
	private TextView textview5;
	
	private FirebaseAuth a_;
	private OnCompleteListener<AuthResult> _a__create_user_listener;
	private OnCompleteListener<AuthResult> _a__sign_in_listener;
	private OnCompleteListener<Void> _a__reset_password_listener;
	private OnCompleteListener<Void> a__updateEmailListener;
	private OnCompleteListener<Void> a__updatePasswordListener;
	private OnCompleteListener<Void> a__emailVerificationSentListener;
	private OnCompleteListener<Void> a__deleteUserListener;
	private OnCompleteListener<Void> a__updateProfileListener;
	private OnCompleteListener<AuthResult> a__phoneAuthListener;
	private OnCompleteListener<AuthResult> a__googleSignInListener;
	private GoogleSignInClient g_;
	private SharedPreferences d_;
	private RequestNetwork rq_;
	private RequestNetwork.RequestListener _rq__request_listener;
	private Intent i_ = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.auth);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear8 = findViewById(R.id.linear8);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear7 = findViewById(R.id.linear7);
		textview3 = findViewById(R.id.textview3);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		linear5 = findViewById(R.id.linear5);
		textview6 = findViewById(R.id.textview6);
		linear6 = findViewById(R.id.linear6);
		imageview2 = findViewById(R.id.imageview2);
		textview5 = findViewById(R.id.textview5);
		a_ = FirebaseAuth.getInstance();
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		rq_ = new RequestNetwork(this);
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent signInIntent = g_.getSignInIntent();
				
				startActivityForResult(signInIntent, REQ_CD_G_);
				_loading(true);
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_chromeTab("https://skybridge.linexware.net.ng/privacy%26policy/");
			}
		});
		
		_rq__request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_loading(false);
				if (_tag.equals("GL")) {
					try {
						m_1 = new Gson().fromJson(_response, HashMap.class);
						if (m_1.get("status").toString().equals("success")) {
							m_2 = new HashMap<>();
							m_2.putAll((Map) m_1.get("data"));
							d_.edit().putString("account_id", m_2.get("account_id").toString()).commit();
							d_.edit().putString("email", m_2.get("email").toString()).commit();
							d_.edit().putString("authentication", m_2.get("account_id").toString()).commit();
							if ((boolean)m_1.get("is_new_account")) {
								i_.setClass(getApplicationContext(), InvitationActivity.class);
								i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								startActivity(i_);
								finish();
							} else {
								_fetch_account(m_2.get("account_id").toString());
							}
						} else {
							CustomToast.showError(AuthActivity.this, "Google login failed", m_1.get("message").toString());
						}
					} catch (Exception e) {
						CustomToast.showError(AuthActivity.this, "An error occurred", "Please try again. If the problem continues, contact the Care Team for assistance.");
					}
				}
				if (_tag.equals("FU")) {
					try {
						m_1 = new Gson().fromJson(_response, HashMap.class);
						if (m_1.get("status").toString().equals("success")) {
							m_2 = new HashMap<>();
							m_2.putAll((Map) m_1.get("data"));
							d_.edit().putString("user", new Gson().toJson(m_2.get("user"))).commit();
							d_.edit().putString("backup", new Gson().toJson(m_2.get("backup"))).commit();
							i_.setClass(getApplicationContext(), DashboardActivity.class);
							i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
							startActivity(i_);
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
							finish();
						} else {
							CustomToast.showError(AuthActivity.this, "Fetching Credential", m_1.get("message").toString());
						}
					} catch (Exception e) {
						CustomToast.showError(AuthActivity.this, "An error occurred", "Please try again. If the problem continues, contact the Care Team for assistance.");
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				_loading(false);
				CustomToast.showError(AuthActivity.this, "Connection Error", "Connection failed, please check your Internet or wifi.");
			}
		};
		
		a__updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		a__updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		a__emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		a__deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		a__phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		a__updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		a__googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_a__create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_a__sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_a__reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_ui_();
		_font_();
		_theme_();
		token_ = "1086390592275-c2h3c2cookv3pl7k5ta0ntkpb78mvqq0.apps.googleusercontent.com";
		GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(token_).requestEmail().build();
		g_ = GoogleSignIn.getClient(this, options);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_G_:
			if (_resultCode == Activity.RESULT_OK) {
				Task<GoogleSignInAccount> _task = GoogleSignIn.getSignedInAccountFromIntent(_data);
				
				try {
					// Google Sign In was successful, authenticate with Firebase
					GoogleSignInAccount account = _task.getResult(ApiException.class);
					
					
					
					_api_google_login(account.getIdToken());
				} catch (ApiException e) {
					//On Fiailure
					final String ErrorOnResultSign = e.getMessage();
					
					
					CustomToast.showError(AuthActivity.this, "SignIn Failed", e.getMessage());
				}
			}
			else {
				_loading(false);
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	public void _ui_() {
		
	}
	
	
	public void _font_() {
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 1);
		
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
			} else {
				_light_();
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
		}
	}
	
	
	public void _api_google_login(final String _token) {
		map_H = new HashMap<>();
		map_H.put("Content-Type", "application/x-www-form-urlencoded");
		rq_.setHeaders(map_H);
		map_D = new HashMap<>();
		map_D.put("id_token", _token);
		rq_.setParams(map_D, RequestNetworkController.REQUEST_PARAM);
		rq_.startRequestNetwork(RequestNetworkController.POST, d_.getString("server-url", "").concat("google-login.php"), "GL", _rq__request_listener);
	}
	
	
	public void _loading(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundResource(R.drawable.bgn_2);
		imageview1.setImageResource(R.drawable.icc_1);
		textview2.setTextColor(0xFFFFFFFF);
		textview3.setTextColor(0xFF9E9E9E);
		textview5.setTextColor(0xFFFFFFFF);
		textview6.setTextColor(0xFF757575);
		textview6.setText(Html.fromHtml("On continue clicked you've agreed to our <a href=\"".concat("https://linexware.net.ng/ontcoin/".concat("\">Terms & Conditions </a>\nand read our <a href=\"".concat("https://linexware.net.ng/ontcoin/".concat("\">Privacy & Policy </a>."))))));
		textview6.setLinkTextColor(0xFFFFFFFF);
		textview6.setLinksClickable(true);
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(17)), 0xFF212121));
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundResource(R.drawable.bgn_1);
		imageview1.setImageResource(R.drawable.icc_2);
		textview2.setTextColor(0xFF000000);
		textview3.setTextColor(0xFF9E9E9E);
		textview5.setTextColor(0xFF000000);
		textview6.setTextColor(0xFF9E9E9E);
		textview6.setText(Html.fromHtml("On continue clicked you've agreed to our <a href=\"".concat("https://linexware.net.ng/ontcoin/".concat("\">Terms & Conditions </a>\nand read our <a href=\"".concat("https://linexware.net.ng/ontcoin/".concat("\">Privacy & Policy </a>."))))));
		textview6.setLinkTextColor(0xFF000000);
		textview6.setLinksClickable(true);
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(17)), 0xFFE0E0E0));
	}
	
	
	public void _chromeTab(final String _link) {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#000000"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(AuthActivity.this, Uri.parse(_link));
			} else {
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#FFFFFF"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(AuthActivity.this, Uri.parse(_link));
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#000000"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(AuthActivity.this, Uri.parse(_link));
				
			} else {
				
				// Light mode
				
				CustomTabColorSchemeParams colorSchemeParams = new CustomTabColorSchemeParams.Builder()
				.setToolbarColor(Color.parseColor("#FFFFFF"))
				.build();
				
				CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
				builder.setDefaultColorSchemeParams(colorSchemeParams);
				builder.setShowTitle(true);
				
				CustomTabsIntent customTabsIntent = builder.build();
				customTabsIntent.launchUrl(AuthActivity.this, Uri.parse(_link));
			}
		}
	}
	
	
	public void _fetch_account(final String _id) {
		map_H = new HashMap<>();
		map_H.put("Content-Type", "application/x-www-form-urlencoded");
		rq_.setHeaders(map_H);
		map_D = new HashMap<>();
		map_D.put("search", _id);
		rq_.setParams(map_D, RequestNetworkController.REQUEST_PARAM);
		rq_.startRequestNetwork(RequestNetworkController.POST, d_.getString("server-url", "").concat("fetch-user.php"), "FU", _rq__request_listener);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}