package com.skybridg.linexware.app;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.browser.*;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.airbnb.lottie.*;
import com.caverock.androidsvg.*;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.gson.Gson;

public class InvitationActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private HashMap<String, Object> m_1 = new HashMap<>();
	private HashMap<String, Object> map_D = new HashMap<>();
	private HashMap<String, Object> map_H = new HashMap<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView textview3;
	private EditText edittext1;
	private LinearLayout linear5;
	private TextView textview6;
	private TextView textview1;
	private TextView textview5;
	
	private RequestNetwork rq_;
	private RequestNetwork.RequestListener _rq__request_listener;
	private SharedPreferences d_;
	private Intent i_ = new Intent();
	private TimerTask t_;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.invitation);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		textview3 = findViewById(R.id.textview3);
		edittext1 = findViewById(R.id.edittext1);
		linear5 = findViewById(R.id.linear5);
		textview6 = findViewById(R.id.textview6);
		textview1 = findViewById(R.id.textview1);
		textview5 = findViewById(R.id.textview5);
		rq_ = new RequestNetwork(this);
		d_ = getSharedPreferences("d_", Activity.MODE_PRIVATE);
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().isEmpty()) {
					CustomToast.showWarning(InvitationActivity.this, "Referral Code", "please enter a valid referral code!!");
					
				} else {
					if (edittext1.getText().toString().length() > 5) {
						map_H = new HashMap<>();
						map_H.put("Content-Type", "application/x-www-form-urlencoded");
						rq_.setHeaders(map_H);
						map_D = new HashMap<>();
						map_D.put("account_id", d_.getString("account_id", ""));
						map_D.put("referral_code", edittext1.getText().toString());
						rq_.setParams(map_D, RequestNetworkController.REQUEST_PARAM);
						rq_.startRequestNetwork(RequestNetworkController.POST, d_.getString("server-url", "").concat("add-referral.php"), "", _rq__request_listener);
						_loading(true);
					} else {
						CustomToast.showWarning(InvitationActivity.this, "Invalid code", "Please enter a valid referral code!!");
						
					}
				}
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i_.setClass(getApplicationContext(), DashboardActivity.class);
				i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(i_);
				finish();
			}
		});
		
		_rq__request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_loading(false);
				try {
					m_1 = new Gson().fromJson(_response, HashMap.class);
					if (m_1.get("status").toString().equals("success")) {
						CustomToast.showSuccess(InvitationActivity.this, "Success", "Invitation Code validated successfully!!");
						t_ = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										i_.setClass(getApplicationContext(), DashboardActivity.class);
										i_.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
										startActivity(i_);
										finish();
									}
								});
							}
						};
						_timer.schedule(t_, (int)(1500));
					} else {
						CustomToast.showError(InvitationActivity.this, "Failed", m_1.get("message").toString());
					}
				} catch (Exception e) {
					CustomToast.showError(InvitationActivity.this, "An error occurred", "Please try again. If the problem continues, contact the Care Team for assistance.");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				_loading(false);
				CustomToast.showError(InvitationActivity.this, "Connection Error", "Connection failed, please check your Internet or wifi.");
			}
		};
	}
	
	private void initializeLogic() {
		if (android.os.Build.VERSION.SDK_INT >= 30) {
			final View rootView = linear1;
			
			// 1. Remember your original Sketchware design paddings before the screen initializes
			final int originalLeft = rootView.getPaddingLeft();
			final int originalTop = rootView.getPaddingTop();
			final int originalRight = rootView.getPaddingRight();
			final int originalBottom = rootView.getPaddingBottom();
			
			rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
					android.graphics.Insets statusBarInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars());
					android.graphics.Insets navigationBarInsets = insets.getInsets(android.view.WindowInsets.Type.navigationBars());
					
					// 2. Add the system safe-zones ON TOP of your original designed paddings
					int finalLeft = originalLeft + statusBarInsets.left;
					int finalTop = originalTop + statusBarInsets.top;
					int finalRight = originalRight + statusBarInsets.right;
					int finalBottom = originalBottom + navigationBarInsets.bottom;
					
					// 3. Apply the perfectly calculated padded framework
					v.setPadding(finalLeft, finalTop, finalRight, finalBottom);
					
					return insets;
				}
			});
		}
		
		_ui_();
		_font_();
		_theme_();
		_onfocus_();
	}
	
	
	@Override
	public void onBackPressed() {
		
	}
	
	@Override
	public void onStart() {
		super.onStart();
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_theme_();
	}
	public void _ui_() {
		
	}
	
	
	public void _font_() {
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font_b.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 1);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 1);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
	}
	
	
	public void _theme_() {
		if (d_.contains("theme")) {
			if (d_.getString("theme", "").equals("dark")) {
				_dark_();
			} else {
				_light_();
			}
		} else {
			if ((getResources().getConfiguration().uiMode
			& android.content.res.Configuration.UI_MODE_NIGHT_MASK)
			== android.content.res.Configuration.UI_MODE_NIGHT_YES) {
				
				// Dark mode
				_dark_();
				
			} else {
				
				// Light mode
				
				_light_();
			}
		}
	}
	
	
	public void _loading(final boolean _visibility) {
		if (_visibility) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
		} else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _onfocus_() {
		edittext1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
					
				} else {
					
					edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF212121));
				}
			}
		});
	}
	
	
	public void _dark_() {
		getWindow().getDecorView().setSystemUiVisibility(0);
		getWindow().setStatusBarColor(0xFF000000);  // Set status bar Color dark
		getWindow().setNavigationBarColor(0xFF000000);  // Set navigation bar Color dark
		linear1.setBackgroundColor(0xFF000000);
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFE0E0E0));
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF212121));
		textview1.setTextColor(0xFFFFFFFF);
		textview3.setTextColor(0xFF9E9E9E);
		textview5.setTextColor(0xFF000000);
		textview6.setTextColor(0xFFFFFFFF);
		edittext1.setTextColor(0xFFFFFFFF);
		edittext1.setHintTextColor(0xFF9E9E9E);
		edittext1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), (int)2, 0xFFE0E0E0, Color.TRANSPARENT));
					
				} else {
					
					edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF212121));
				}
			}
		});
	}
	
	
	public void _light_() {
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR   // Light status bar icons
		| View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR  // Light navigation bar icons (API 26+)
		);
		
		getWindow().setStatusBarColor(0xFFFFFFFF);  // Set status bar to white
		getWindow().setNavigationBarColor(0xFFFFFFFF);  // Set navigation bar to white
		linear1.setBackgroundColor(0xFFFFFFFF);
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFF000000));
		edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(15)), 0xFFEEEEEE));
		textview1.setTextColor(0xFF000000);
		textview3.setTextColor(0xFF9E9E9E);
		textview5.setTextColor(0xFFFFFFFF);
		textview6.setTextColor(0xFF000000);
		edittext1.setTextColor(0xFF000000);
		edittext1.setHintTextColor(0xFF9E9E9E);
		edittext1.setOnFocusChangeListener(new View.OnFocusChangeListener() {
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if (hasFocus) {
					edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(17)), (int)2, 0xFF000000, Color.TRANSPARENT));
					
				} else {
					
					edittext1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)SketchwareUtil.getDip(getApplicationContext(), (int)(17)), 0xFFEEEEEE));
				}
			}
		});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}